package com.cookbook.launch_for_result;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class RecognizerIntentExample extends Activity {
    private static final int RECOGNIZER_EXAMPLE = 1001;
    private TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        tv = (TextView) findViewById(R.id.text_result);

        // �{�^�����X�i�[�̐ݒ�
        Button startButton = (Button) findViewById(R.id.trigger);
        startButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                // RecognizerIntent�͉����𑣂��āA�e�L�X�g��Ԃ��܂�                   
                Intent intent = 
                    new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); 

                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, 
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); 
                intent.putExtra(RecognizerIntent.EXTRA_PROMPT, 
                "Say a word or phrase{\textbackslashnthen it will appear on the screen."); 
                startActivityForResult(intent, RECOGNIZER_EXAMPLE); 
            }
        });
    }

    @Override 
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent data) { 
        if (requestCode == RECOGNIZER_EXAMPLE && resultCode == RESULT_OK) { 
            // �Ԃ��ꂽ�f�[�^�́A�������͂Ɉ�v�������X�g
            ArrayList<String> result = 
                data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS); 

            // �X�N���[���֕\��
            tv.setText(result.toString());
        } 

        super.onActivityResult(requestCode, resultCode, data); 
    } 
}
