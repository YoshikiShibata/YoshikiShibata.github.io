package com.cookbook.relative_layout;

import android.app.Activity;
import android.os.Bundle;

public class RelativeLayoutEx extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
}