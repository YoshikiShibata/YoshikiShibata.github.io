package com.cookbook.handler_ui;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HandlerUpdateUi extends Activity {
    TextView av; // UI�Q��
    int text_string = R.string.start;
    int background_color = Color.DKGRAY;
    
    final Handler mHandler = new Handler();
    // UI�X���b�h�֌��ʂ��|�X�g���邽�߂�Runnable���쐬
    final Runnable mUpdateResults = new Runnable() {
        public void run() {
            av.setText(text_string);
            av.setBackgroundColor(background_color);
        }
    };
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        av = (TextView) findViewById(R.id.computation_status);
        
        Button actionButton = (Button) findViewById(R.id.action);
        actionButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                do_work();
            }
        });
    }
    
    // UI�X�V�𔺂��v�Z��v���鏈����
    private void do_work() {
        Thread thread = new Thread(new Runnable() {
        public void run() {
            text_string = R.string.start;
            background_color = Color.DKGRAY;
            mHandler.post(mUpdateResults);
            
            computation(1);
            text_string = R.string.first;
            background_color = Color.BLUE;
            mHandler.post(mUpdateResults);
            
            computation(2);
            text_string = R.string.second;
            background_color = Color.GREEN;
            mHandler.post(mUpdateResults);
            }
        });
        thread.start();
    }
    
    final static int SIZE = 1000; // ���Ԃ�v����̂ɏ\���ȑ傫��
    double tmp;
    private void computation(int val) {
        for (int i = 0; i < SIZE; i++)
            for (int j = 0; j < SIZE; j++)
                tmp = val * Math.log(i + 1) / Math.log1p(j + 1);
    }
}
