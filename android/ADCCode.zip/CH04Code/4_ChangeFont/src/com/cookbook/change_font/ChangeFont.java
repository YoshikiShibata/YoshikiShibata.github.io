package com.cookbook.change_font;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ChangeFont extends Activity {
    TextView tv;
    private int color_vals[] = {R.color.start, R.color.mid, R.color.last};
    int idx = 0;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        tv = (TextView) findViewById(R.id.mod_text);
        
        Button changeFont = (Button) findViewById(R.id.change);
        changeFont.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                tv.setTextColor(getResources().getColor(color_vals[idx]));
                idx = (idx + 1) % 3;
            }
        });
    }
}
