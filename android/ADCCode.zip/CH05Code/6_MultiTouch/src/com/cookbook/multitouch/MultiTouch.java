package com.cookbook.multitouch;

import android.app.Activity;
import android.graphics.Matrix;
import android.os.Bundle;
import android.util.FloatMath;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.ImageView;

public class MultiTouch extends Activity implements OnTouchListener {
    // �摜���ړ�����ъg��E�k�����邽�߂�Matrix�C���X�^���X
    Matrix matrix = new Matrix();
    Matrix eventMatrix = new Matrix();


    // �^�b�`��ԂƂ��Ď�蓾��l
    final static int NONE = 0;
    final static int DRAG = 1;
    final static int ZOOM = 2;
    int touchState = NONE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        ImageView view = (ImageView) findViewById(R.id.imageView);
        view.setOnTouchListener(this);
    }

    final static float MIN_DIST = 50;
    static float eventDistance = 0;
    static float centerX = 0, centerY = 0;
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        ImageView view = (ImageView) v;

        switch (event.getAction() & MotionEvent.ACTION_MASK) {
        case MotionEvent.ACTION_DOWN:
            // ��^�b�`�C�x���g���J�n: �^�b�`�_�E���ʒu���L��
            touchState = DRAG;
            centerX = event.getX(0);
            centerY = event.getY(0);
            eventMatrix.set(matrix);
            break;

        case MotionEvent.ACTION_POINTER_DOWN:
            // ���^�b�`�C�x���g���J�n: �����Ɛ^�񒆂��L��
            eventDistance = calcDistance(event);
            calcMidpoint(event);
            if (eventDistance > MIN_DIST) {
                eventMatrix.set(matrix);
                touchState = ZOOM;
            }
            break;

        case MotionEvent.ACTION_MOVE:
            if (touchState == DRAG) {      
                // �P��w�ł̃h���b�O�F�Ή������ϊ����s��
                matrix.set(eventMatrix);
                matrix.setTranslate(event.getX(0) - centerX, 
                                    event.getY(0) - centerY);
            } else if (touchState == ZOOM) {
                // ��{�w�ł̊g��E�k���F�^�񒆂𒆐S�ɑΉ������g��E�k�����s��
                float dist = calcDistance(event);

                if (dist > MIN_DIST) {
                    matrix.set(eventMatrix);
                    float scale = dist / eventDistance;
                    matrix.postScale(scale, scale, centerX, centerY);                
                }
            }

            // �ϊ��̎��s
            view.setImageMatrix(matrix);
            break;

        case MotionEvent.ACTION_UP:
        case MotionEvent.ACTION_POINTER_UP:
            touchState = NONE;
            break;
        }       

        return true; 
    }

    private float calcDistance(MotionEvent event) {
        float x = event.getX(0) - event.getX(1);
        float y = event.getY(0) - event.getY(1);
        return FloatMath.sqrt(x * x + y * y);
    }

    private void calcMidpoint(MotionEvent event) {
        centerX = (event.getX(0) + event.getX(1)) / 2;
        centerY = (event.getY(0) + event.getY(1)) / 2;
    }
}
