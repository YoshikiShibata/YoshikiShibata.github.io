package com.cookbook.image_manip;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.widget.ImageView;

public class ImageManipulation extends Activity {
    static final String CAMERA_PIC_DIR = "/DCIM/Camera/";
    ImageView iv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        iv = (ImageView) findViewById(R.id.my_image);

        String ImageDir = Environment.getExternalStorageDirectory().getAbsolutePath() 
        + CAMERA_PIC_DIR;

        Intent i = new Intent(this, ListFiles.class);
        i.putExtra("directory", ImageDir);
        startActivityForResult(i,0);        
    }

    @Override
    protected void onActivityResult(int requestCode,
            int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 0 && resultCode==RESULT_OK) {
            String tmp = data.getExtras().getString("clickedFile");
            Bitmap ImageToChange= BitmapFactory.decodeFile(tmp);  
            process_image(ImageToChange);
        }

    }

    void process_image(Bitmap image) {
        Bitmap bm = Bitmap.createScaledBitmap(image, 480, 320, false);
        int width = bm.getWidth();
        int height = bm.getHeight();
        int x = width >> 1; 
        int y = height >> 1;
        int[] pixels1 = new int[(width * height)];
        int[] pixels2 = new int[(width * height)];
        int[] pixels3 = new int[(width * height)];
        int[] pixels4 = new int[(width * height)];
        bm.getPixels(pixels1, 0, width, 0, 0, x, y);
        bm.getPixels(pixels2, 0, width, x, 0, x, y);
        bm.getPixels(pixels3, 0, width, 0, y, x, y);
        bm.getPixels(pixels4, 0, width, x, y, x, y);
        if (bm.isMutable()) {
            bm.setPixels(pixels2, 0, width, 0, 0, x, y);
            bm.setPixels(pixels4, 0, width, x, 0, x, y);
            bm.setPixels(pixels1, 0, width, 0, y, x, y);
            bm.setPixels(pixels3, 0, width, x, y, x, y);
        }
        iv.setImageBitmap(bm);
    }
}
