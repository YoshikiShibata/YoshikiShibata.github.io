package com.cookbook.hardware.telephony;

import android.app.Activity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.widget.TextView;

public class TelephonyApp extends Activity {
    TextView tv1;
    TelephonyManager telManager;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        tv1 =(TextView) findViewById(R.id.tv1);
        telManager = (TelephonyManager)
                         getSystemService(TELEPHONY_SERVICE);
        StringBuilder sb = new StringBuilder();
        sb.append("deviceid:")
          .append(telManager.getDeviceId()).append("\n");
        sb.append("device Software Ver:")
          .append(telManager.getDeviceSoftwareVersion()).append("\n");
        sb.append("Line number:")
          .append(telManager.getLine1Number()).append("\n");
        sb.append("Network Country ISO:")
          .append(telManager.getNetworkCountryIso()).append("\n");
        sb.append("Network Operator:")
          .append(telManager.getNetworkOperator()).append("\n");
        sb.append("Network Operator Name:")
          .append(telManager.getNetworkOperatorName()).append("\n");
        sb.append("Sim Country ISO:")
          .append(telManager.getSimCountryIso()).append("\n");
        sb.append("Sim Operator:")
          .append(telManager.getSimOperator()).append("\n");
        sb.append("Sim Operator Name:")
          .append(telManager.getSimOperatorName()).append("\n");
        sb.append("Sim Serial Number:")
          .append(telManager.getSimSerialNumber()).append("\n");
        sb.append("Subscriber Id:")
          .append(telManager.getSubscriberId()).append("\n");
        sb.append("Voice Mail Alpha Tag:")
          .append(telManager.getVoiceMailAlphaTag()).append("\n");
        sb.append("Voice Mail Number:")
          .append(telManager.getVoiceMailNumber()).append("\n");
        tv1.setText(sb.toString());
    }
}
