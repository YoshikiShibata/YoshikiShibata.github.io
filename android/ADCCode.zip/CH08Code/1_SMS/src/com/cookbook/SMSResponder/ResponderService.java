package com.cookbook.SMSResponder;

import java.util.ArrayList;

import android.app.Activity;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

public class ResponderService extends Service {
    // SMS����M�����Ƃ���Android�V�X�e���ɂ���ċN������鏈��
    private static final String RECEIVED_ACTION =
        "android.provider.Telephony.SMS_RECEIVED";
    private static final String SENT_ACTION = "SENT_SMS";
    private static final String DELIVERED_ACTION = "DELIVERED_SMS";
    
    SharedPreferences myprefs;
    
    @Override
    public void onCreate() {
        super.onCreate();
        myprefs = PreferenceManager.getDefaultSharedPreferences(this);
        
        registerReceiver(sentReceiver, new IntentFilter(SENT_ACTION));
        registerReceiver(deliverReceiver, new IntentFilter(DELIVERED_ACTION));
        
        IntentFilter filter = new IntentFilter(RECEIVED_ACTION);
        registerReceiver(receiver, filter);
        
        IntentFilter attemptedfilter = new IntentFilter(SENT_ACTION);
        registerReceiver(sender, attemptedfilter);
    }
    
    private BroadcastReceiver sender = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            if (i.getAction().equals(SENT_ACTION)) {
                if (getResultCode() != Activity.RESULT_OK) {
                    String recipient = i.getStringExtra("recipient");
                    Log.v("ResponderService", "In requestReceived " + recipient);
                }
            }
        }
    };
    
    BroadcastReceiver sentReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent in) {
            switch (getResultCode()) {
            case Activity.RESULT_OK:
                // SMS���b�Z�[�W�̑��M������
                smsSent();
                break;
            default:
                // SMS���b�Z�[�W�̑��M�����s
                smsFailed();
                break;
            }
        }
    };
        
    public void smsSent() {
         Toast.makeText(this, "SMS sent", Toast.LENGTH_SHORT);
    }
    public void smsFailed() {
        Toast.makeText(this, "SMS sent failed", Toast.LENGTH_SHORT);
    }
    public void smsDelivered() {
        Toast.makeText(this, "SMS delivered", Toast.LENGTH_SHORT);
    }
        
    BroadcastReceiver deliverReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent in) {
            // SMS�̎�M����
            smsDelivered();
        }
    };
        
    BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent in) {
            Log.v("ResponderService", "On Receive");
            if (!in.getAction().equals(RECEIVED_ACTION))
                return;
                
            Log.v("ResponderService", "On SMS RECEIVE");
            Bundle bundle = in.getExtras();
            if (bundle == null)
                return;
						
            Object[] pdus = (Object[])bundle.get("pdus");
            SmsMessage[] messages = new SmsMessage[pdus.length];
            for (int i = 0; i < pdus.length; i++) {
                Log.v("ResponderService","FOUND MESSAGE");
                messages[i] =
                    SmsMessage.createFromPdu((byte[])pdus[i]);
            }
            for (SmsMessage message: messages) {
                String requester = message.getOriginatingAddress();
                if (requester != null) {
                    Log.v("ResponderService", "In requestReceived");
                    respond(requester);
                    return;
                }
            }
        }
    };
        
    @Override
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);
    }
    
    private void respond(String requester) {
        Log.v("ResponderService", "Responing to " + requester);
        String reply = myprefs.getString("reply",
                    "Thank you for your message. I am busy now. "
                    + "I will call you later");
        SmsManager sms = SmsManager.getDefault();
        Intent sentIn = new Intent(SENT_ACTION);
        PendingIntent sentPIn = PendingIntent.getBroadcast(this,
                                    0, sentIn, 0);
        Intent deliverIn = new Intent(DELIVERED_ACTION);
        PendingIntent deliverPIn = PendingIntent.getBroadcast(this,
                                    0, deliverIn, 0);
        ArrayList<String> msgs = sms.divideMessage(reply);
        ArrayList<PendingIntent> sentIns = new ArrayList<PendingIntent>();
        ArrayList<PendingIntent> deliverIns =
                                    new ArrayList<PendingIntent>();
        for (int i = 0; i < msgs.size(); i++) {
            sentIns.add(sentPIn);
            deliverIns.add(deliverPIn);
        }
        sms.sendMultipartTextMessage(requester, null,
                            msgs, sentIns, deliverIns);
    }
    
    @Override
    public void onDestroy() {
        unregisterReceiver(receiver);
        unregisterReceiver(sender);
        super.onDestroy();
    }
    
    @Override
    public IBinder onBind(Intent arg0) {
        return null;
    }
}
