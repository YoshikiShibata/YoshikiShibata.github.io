package com.cookbook.lastlocation;

import android.app.Activity;
import android.content.Context;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.TextView;

public class MyLocation extends Activity {
    LocationManager mLocationManager;
    TextView tv;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        tv = (TextView) findViewById(R.id.tv1);
        mLocationManager = (LocationManager)
                getSystemService(Context.LOCATION_SERVICE);
                
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        criteria.setPowerRequirement(Criteria.POWER_LOW);
        String locationprovider =
                mLocationManager.getBestProvider(criteria,true);
        Location mLocation =
                mLocationManager.getLastKnownLocation(locationprovider);
                
        tv.setText("Last location lat:" + mLocation.getLatitude()
                   + " long:" + mLocation.getLongitude());
    }
}
