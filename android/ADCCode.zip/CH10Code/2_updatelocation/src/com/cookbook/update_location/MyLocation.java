package com.cookbook.update_location;

import android.app.Activity;
import android.content.Context;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.TextView;

public class MyLocation extends Activity implements LocationListener {
    LocationManager mLocationManager;
    TextView tv;
    Location mLocation;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        tv = (TextView) findViewById(R.id.tv1);
        
        mLocationManager = (LocationManager)
                getSystemService(Context.LOCATION_SERVICE);
                
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        criteria.setPowerRequirement(Criteria.POWER_LOW);
        String locationprovider = 
                mLocationManager.getBestProvider(criteria,true);

        mLocation = mLocationManager.getLastKnownLocation(locationprovider);
        mLocationManager.requestLocationUpdates(
                locationprovider, 5000, 2.0f, this);
    }
    
    @Override
    public void onLocationChanged(Location location) {
        mLocation = location;
        showupdate();
    }
    
    // �����̃��\�b�h�͕K�v
    public void onProviderDisabled(String provider) { }
    public void onProviderEnabled(String provider) { }
    public void onStatusChanged(String provider,
                                int status, Bundle extras) { }
    
    private void showupdate() {
        tv.setText("Last location lat:"+mLocation.getLatitude()
                   + " long:" + mLocation.getLongitude());
    }
}
