package com.cookbook.show_providers;

import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.TextView;

public class MyLocation extends Activity {
    LocationManager mLocationManager;
    TextView tv;
    Location mLocation;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        tv = (TextView) findViewById(R.id.tv1);
        mLocationManager = (LocationManager)
                getSystemService(Context.LOCATION_SERVICE);
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        criteria.setPowerRequirement(Criteria.POWER_LOW);
        String locationprovider =
                mLocationManager.getBestProvider(criteria, true);

        List<String> providers = mLocationManager.getProviders(true);
        StringBuilder sb = new StringBuilder("Providers:\n");
        for (int i = 0; i < providers.size(); i++) {
            mLocationManager.requestLocationUpdates(
                    providers.get(i), 5000, 2.0f, new LocationListener() {
                // �����̃��\�b�h�͕K�v
                public void onLocationChanged(Location location) { }
                public void onProviderDisabled(String provider) { }
                public void onProviderEnabled(String provider) { }
                public void onStatusChanged(String provider,
                                            int status, Bundle extras) { }
            });
            sb.append(providers.get(i)).append(": \n");
            mLocation =
                mLocationManager.getLastKnownLocation(providers.get(i));
            if (mLocation != null) {
                sb.append(mLocation.getLatitude()).append(" , ");
                sb.append(mLocation.getLongitude()).append("\n");
            } else {
                sb.append("Location can not be found");
            }
        }
        tv.setText(sb.toString());
    }
}
