package com.cookbook.geocoding;

import java.io.IOException;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.TextView;

public class MyLocation extends Activity {
    LocationManager mLocationManager;
    Location mLocation;
    TextView tv;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        tv = (TextView) findViewById(R.id.tv1);
        
        mLocationManager = (LocationManager)
                getSystemService(Context.LOCATION_SERVICE);
                
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        criteria.setPowerRequirement(Criteria.POWER_LOW);
        String locationprovider =
            mLocationManager.getBestProvider(criteria, true);
        mLocation =
            mLocationManager.getLastKnownLocation(locationprovider);
            
        List<Address> addresses;
        String myAddress = "Seattle,WA";
        Geocoder gc = new Geocoder(this);
        try {
            addresses = gc.getFromLocationName(myAddress, 1);
            if (addresses != null && !addresses.isEmpty()) {
                Address x = addresses.get(0);
                StringBuilder sb = new StringBuilder("Address:\n");
                sb.append("latitude: ").append(x.getLatitude());
                sb.append("\nlongitude: ").append(x.getLongitude());
                tv.setText(sb.toString());
            }
        } catch (IOException e) {
            tv.setText(e.getMessage());
        }
    }
}
