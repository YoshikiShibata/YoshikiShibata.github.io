package com.cookbook.adding_markers;

import java.io.IOException;
import java.util.List;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.widget.TextView;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

public class MyLocation extends MapActivity {
    TextView tv;
    List<Overlay> mapOverlays;
    MyMarkerLayer markerlayer;
    private MapController mc;
    public static Context mContext;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(R.layout.main);
        MapView mapView = (MapView) findViewById(R.id.map1);
        tv = (TextView) findViewById(R.id.tv1);
        
        mapOverlays = mapView.getOverlays();
        Drawable drawable =
                this.getResources().getDrawable(R.drawable.icon);
        markerlayer = new MyMarkerLayer(drawable);
        
        List<Address> addresses;
        String myAddress = "1600 Amphitheatre Parkway, Mountain View, CA";
        
        int geolat = 0;
        int geolon = 0;
        
        Geocoder gc = new Geocoder(this);
        try {
            addresses = gc.getFromLocationName(myAddress, 1);
            if (addresses != null && !addresses.isEmpty()) {
                Address x = addresses.get(0);
                
                geolat = (int)(x.getLatitude()*1E6);
                geolon = (int)(x.getLongitude()*1E6);
            }
        } catch (IOException e) {
            tv.setText(e.getMessage());
        }
        
        mapView.setBuiltInZoomControls(true);
        GeoPoint point = new GeoPoint(geolat, geolon);
        mc = mapView.getController();
        mc.animateTo(point);
        mc.setZoom(3);
        
        OverlayItem overlayitem =
                new OverlayItem(point, "Google Campus", "I am at Google");
        markerlayer.addOverlayItem(overlayitem);
        mapOverlays.add(markerlayer);
    }
    
    @Override
    protected boolean isRouteDisplayed() { return false; }
}
