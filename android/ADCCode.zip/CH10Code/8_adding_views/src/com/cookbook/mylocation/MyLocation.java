package com.cookbook.mylocation;

import java.io.IOException;
import java.util.List;

import android.content.Context;
//import android.content.Intent;
import android.graphics.Color;
//import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

//import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
//import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
//import com.google.android.maps.Overlay;

public class MyLocation extends MapActivity {
    TextView tv;
//    List<Overlay> mapOverlays;
//    MyMarkerLayer markerlayer;
//    private MapController mc;
    MapView.LayoutParams mScreenLayoutParams;
    public static Context mContext;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(R.layout.main);

        MapView mapView = (MapView) findViewById(R.id.map1);
//        mc = mapView.getController();
        tv = (TextView) findViewById(R.id.tv1);
//        mapOverlays = mapView.getOverlays();
//        Drawable drawable = this.getResources().getDrawable(R.drawable.icon);
//        markerlayer = new MyMarkerLayer(drawable);

        List<Address> addresses;
        String myAddress = "1600 Amphitheatre Parkway, Mountain View, CA";

        int geolat = 0;
        int geolon = 0;

        Geocoder gc = new Geocoder(this);
        try {
            addresses = gc.getFromLocationName(myAddress, 1);
            if (addresses != null && !addresses.isEmpty()) {
                Address x = addresses.get(0);
            
                StringBuilder sb = new StringBuilder("Address:n");
                geolat =(int)(x.getLatitude() * 1E6);
                geolon = (int)(x.getLongitude() * 1E6);
                sb.append("latitude: ").append(geolat).append("n");
                sb.append("longitude: ").append(geolon);
                tv.setText(sb.toString());
            }
        } catch (IOException e) {
            tv.setText(e.getMessage());
        }
    
        int x = 50;
        int y = 50;
        mScreenLayoutParams =
                new MapView.LayoutParams(MapView.LayoutParams.WRAP_CONTENT,
                                         MapView.LayoutParams.WRAP_CONTENT,
                                         x, y, MapView.LayoutParams.LEFT);

        final TextView tv = new TextView(this);
        tv.setText("Adding View to Google Map");
        tv.setTextColor(Color.BLUE);
        tv.setTextSize(20);
        mapView.addView(tv, mScreenLayoutParams);
        
        x = 250;
        y = 250;
        mScreenLayoutParams =
                new MapView.LayoutParams(MapView.LayoutParams.WRAP_CONTENT,
                                         MapView.LayoutParams.WRAP_CONTENT,
                                         x, y,
                                         MapView.LayoutParams.BOTTOM_CENTER);

        Button clickMe = new Button(this);
        clickMe.setText("Click Me");
        clickMe.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                tv.setTextColor(Color.RED);
                tv.setText("Let's play");
            }
        });
        
        mapView.addView(clickMe, mScreenLayoutParams);
    }
    
    @Override
    protected boolean isRouteDisplayed() { return false; }
}
