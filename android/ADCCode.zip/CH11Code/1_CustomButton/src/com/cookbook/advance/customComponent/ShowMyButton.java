package com.cookbook.advance.customComponent;

import android.app.Activity;
import android.os.Bundle;

public class ShowMyButton extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        setContentView(R.layout.main);
        MyButton myb = (MyButton)findViewById(R.id.mybutton1);
        myb.setText("Hello Students");
        myb.setTextSize(40);
    }
}
