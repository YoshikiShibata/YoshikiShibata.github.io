package com.cookbook.android.debug.traceview;

import android.app.Activity;
import android.os.Bundle;
import android.os.Debug;

public class testfactorial extends Activity {
    public final String tag="testfactorial";
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        factorial(10);
    }
    
    public int factorial(int n) {
        Debug.startMethodTracing(tag);
        int result=1;
        for (int i = 1; i <= n; i++) {
            result*=i;
        }
        Debug.stopMethodTracing();
        return result;
    }
}
