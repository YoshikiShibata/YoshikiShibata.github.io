import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

class LinkedListTest { // 1.4 version
    
    public static void main(String[] args) {
        List list = new LinkedList();
        list.add(new Integer(10));
        list.add(new Integer(20));

        int total = 0;
        for (Iterator i = list.iterator(); i.hasNext(); ) {
            total += ((Integer) i.next()).intValue(); // �L���X�g���K�v
        }
        System.out.println("total = " + total);
    }
}