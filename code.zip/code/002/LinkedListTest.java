import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

class LinkedListTest { // 5.0 version
    
    public static void main(String[] args) {
        List<Integer> list = new LinkedList<Integer>(); // *
        list.add(new Integer(10));
        list.add(new Integer(20));

        int total = 0;
        for (Iterator<Integer> i = list.iterator(); i.hasNext(); ) { // *
            total += i.next().intValue(); // �L���X�g���s�v
        }
        System.out.println("total = " + total);
    }
}