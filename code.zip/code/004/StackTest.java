class StackTest {
    public static void main(String[] args) {
        Stack s = new Stack(args.length);

        for (int i = 0; i < args.length; i++)
            s.push(new Integer(args[i]));

        int total = 0;
        for (int i = 0; i < args.length; i++)
            total += ((Integer) s.pop()).intValue();

        System.out.println("total = " + total);
    }
}