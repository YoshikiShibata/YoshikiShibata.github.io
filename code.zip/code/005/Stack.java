import java.util.EmptyStackException;

class Stack<E> {                // [1]
    private E[] elements;       // [2]
    private int size = 0;

    public Stack(int initialCapacity) {
        elements = (E[]) new Object[initialCapacity]; // [3]
    }

    public void push(E e) {     // [4]
        ensureCapacity();
        elements[size++] = e;
    }

    public E pop() {            // [5]
        if (size == 0)
            throw new EmptyStackException();
        E e = elements[--size];    // [6]
        elements[size] = null;
        return e;
    }

    private void ensureCapacity() {
        if (elements.length == size) {
            E[] oldElements = elements;            
            elements = (E[]) new Object[2 * elements.length + 1]; // [7]
            System.arraycopy(oldElements, 0, elements, 0, size);
        }
    }
}