class StackTest {
    public static void main(String[] args) {
        Stack<Integer> s = new Stack<Integer>(args.length);  // [8]

        for (int i = 0; i < args.length; i++)
            s.push(new Integer(args[i]));

        int total = 0;
        for (int i = 0; i < args.length; i++)
            total += s.pop(); // [9]
            
        System.out.println("total = " + total);
    }
}