import java.util.Arrays;

class EmployeeName implements Comparable<EmployeeName> { // [1]
    public final String firstName;
    public final String lastName;

    public EmployeeName(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public int compareTo(EmployeeName that) {         // [2]
        if (lastName.compareTo(that.lastName) != 0)
            return lastName.compareTo(that.lastName);
        return firstName.compareTo(that.firstName);
    }

    public String toString() {
        return firstName + " " + lastName;
    }

    public static void main(String[] args) {
        EmployeeName[] names = { 
            new EmployeeName("Yoshiki", "Shibata"),
            new EmployeeName("David", "Nesbitt"),
            new EmployeeName("Steve", "Bartlett") };

        Arrays.sort(names);
        for (int i = 0; i < names.length; i++)
            System.out.println(names[i]);
                        
    }
}