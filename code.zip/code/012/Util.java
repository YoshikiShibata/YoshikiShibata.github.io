class Util {

    static <T> void swap(T[] a, int i, int j) {
        T temp = a[i];
        a[i] = a[j];
        a[j] = temp;
    }

    static <S> void print(S[] a) {
        for (S s : a)
            System.out.println(s + " ");
    }

    public static void main(String[] args) {
        Integer[] intArray = new Integer[args.length];

        for (int i = 0; i < args.length; i++)
            intArray[i] = new Integer(args[i]);
        swap(intArray, 0, intArray.length - 1);
        print(intArray);
    }
}