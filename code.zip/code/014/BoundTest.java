import java.util.Collection;
import java.util.ArrayList;
import java.util.Iterator;

class BoundTest {

    public static <T extends Comparable<T>> //[1]
      T max(Collection<T> coll) {  // [2]
        Iterator<T> i = coll.iterator();
        T candidate = i.next();

        while(i.hasNext()) {
            T next = i.next();
            if (next.compareTo(candidate) > 0) // [3]
                candidate = next;
        }
        return candidate;
    }


    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<Integer>();

        for (int i = 0; i < args.length; i++)
            list.add(new Integer(args[i]));

        System.out.println("max = " + max(list)); // [4]
    }
}