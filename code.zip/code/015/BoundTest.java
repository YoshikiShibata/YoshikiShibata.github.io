import java.util.Collection;
import java.util.ArrayList;
import java.util.Iterator;

class BoundTest {

    public static Comparable max(Collection coll) {
        Iterator i = coll.iterator();
        Comparable candidate = (Comparable)i.next();

        while(i.hasNext()) {
            Comparable next = (Comparable) i.next();
            if (next.compareTo(candidate) > 0)
                candidate = next;
        }
        return candidate;
    }

    public static void main(String[] args) {
        ArrayList list = new ArrayList();

        for (int i = 0; i < args.length; i++)
            list.add(new Integer(args[i]));

        System.out.println("max = " + ((Integer)max(list)));
    }
}