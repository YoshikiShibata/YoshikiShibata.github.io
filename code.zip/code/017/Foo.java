public class Foo {
    public <T> Foo(T x) { /* ... */ }

    public static void main(String[] args) {
        Foo f = new <String>Foo("Hello");
    }
}