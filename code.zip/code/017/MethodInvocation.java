class MethodInvocation {

    public <T extends Comparable<T>> void foo(T f) { 
        System.out.println("the first foo is invoked");
    }

    public <T> void foo(T f) {
        System.out.println("the second foo is invoked");
    }

    public static void main(String[] args) {
        MethodInvocation m = new MethodInvocation();
        m.foo(1);
        m.<Object>foo(1);
    }
}