interface Job<E extends Exception> {
    void run() throws E;
}