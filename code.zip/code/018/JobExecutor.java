class JobExecutor {
    public static <E extends Exception> void execute(Job<E> job) throws E {
        job.run();
    }
}