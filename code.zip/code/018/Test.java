import java.io.FileNotFoundException;

class Test {
    public static void main(String[] args) {
        JobExecutor.execute(new Job<FileNotFoundException>() {
            public void run() throws FileNotFoundException {
                /* ... */
            }
        });
    }
}