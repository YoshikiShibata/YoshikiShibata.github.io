import java.util.EmptyStackException;
import java.util.Iterator;
import java.util.NoSuchElementException;

class Stack<E> implements Iterable<E> {             
    private E[] elements;      
    private int size = 0;

    public Stack(int initialCapacity) {
        elements = (E[]) new Object[initialCapacity];
    }

    public void push(E e) { 
        ensureCapacity();
        elements[size++] = e;
    }

    public E pop() {            
        if (size == 0)
            throw new EmptyStackException();
        E e = elements[--size];    
        elements[size] = null;
        return e;
    }

    public Iterator<E> iterator() {
        return new Iterator<E>() {
            private int pos = 0;
            
            public boolean hasNext() {
                return (pos < size);
            }

            public E next() {
                if (pos >= size)
                    throw new NoSuchElementException();
                return elements[pos++];
            }

            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    private void ensureCapacity() {
        if (elements.length == size) {
            E[] oldElements = elements;            
            elements = (E[]) new Object[2 * elements.length + 1]; 
            System.arraycopy(oldElements, 0, elements, 0, size);
        }
    }
}
