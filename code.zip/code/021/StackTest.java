class StackTest {

    public static void main(String[] args) {
        Stack<Integer> s = new Stack<Integer>(args.length);  

        for (int i = 0; i < args.length; i++)
            s.push(new Integer(args[i]));

        int total = 0;
        for (Integer i: s) 
            total += i;
            
        System.out.println("total = " + total);
    }
}