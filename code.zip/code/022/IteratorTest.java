import java.util.NoSuchElementException;
import java.util.Iterator;

class IteratorTest {

    public static Iterator<Integer> walkThrough(final Integer[] objs) {
        class Iter implements Iterator<Integer> {
            private int pos = 0;
            public boolean hasNext() {
                return (pos < objs.length);
            }
            public Integer next() {      // *
                if (pos >= objs.length)
                    throw new NoSuchElementException();
                return objs[pos++];
            }
            public void remove() {
                throw new UnsupportedOperationException();
            }
        }

        return new Iter();
    }

    public static void main(String[] args) {
        Integer[] objs = new Integer[args.length];

        for (int i = 0; i < args.length; i++)
            objs[i] = new Integer(args[i]);

        int total = 0;
        for (Iterator<Integer> i = walkThrough(objs); i.hasNext(); )
            total += i.next();
            
        System.out.println("total = " + total);

    }
}