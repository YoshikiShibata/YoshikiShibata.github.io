class C {
    C dup() {
        return new C();
    }
    public String toString() {
        return "instance of class C";
    }
}