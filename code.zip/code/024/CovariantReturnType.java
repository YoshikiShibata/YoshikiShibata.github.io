class CovariantReturnType {
    public static void main(String[] args) {
        C c = new D();
        C dup = c.dup();
        System.out.println(dup);
    }
}