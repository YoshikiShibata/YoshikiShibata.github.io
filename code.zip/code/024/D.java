class D extends C {
    D dup() { // ���ϖ߂�l�^
        return new D();
    }
    public String toString() {
        return "instance of class D";
    }
}