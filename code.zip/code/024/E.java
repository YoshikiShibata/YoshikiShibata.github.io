class E extends D {
    E dup() {
        return new E();
    }
    public String toString() {
        return "instance of class E";
    }
}