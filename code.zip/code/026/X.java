interface X {
    Object foo();
}