interface Y {
    Number foo();
}