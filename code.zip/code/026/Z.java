interface Z {
    Integer foo();
}