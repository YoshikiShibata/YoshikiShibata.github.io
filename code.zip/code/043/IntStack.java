import java.util.*;

class IntStack { // 1.4 version
    private List elements;

    public IntStack(int initialCapacity) {
        elements = new ArrayList(initialCapacity);
    }

    public void push(int e) {
        elements.add(new Integer(e));
    }

    public int pop() {
        if (elements.size() == 0)
            throw new EmptyStackException();
        Integer e = (Integer) elements.remove(elements.size() - 1);
        return e.intValue();
    }
}