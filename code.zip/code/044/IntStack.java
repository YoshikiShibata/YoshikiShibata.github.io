import java.util.*;

class IntStack { // 5.0 version
    private List<Integer> elements;

    public IntStack(int initialCapacity) {
        elements = new ArrayList<Integer>(initialCapacity);
    }

    public void push(int e) {
        elements.add(e);
    }

    public int pop() {
        if (elements.size() == 0)
            throw new EmptyStackException();
        return elements.remove(elements.size() - 1);
    }
}