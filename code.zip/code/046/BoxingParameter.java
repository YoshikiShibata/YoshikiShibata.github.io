class BoxingParameter {
    public static void main(String[] args) {
        showInteger(10);
        showInteger(20);
    }
    public static void showInteger(Integer i) {
        System.out.println("value of integer = " + i);
    }
}