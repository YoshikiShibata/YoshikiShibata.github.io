class UnboxingParameter {
    public static void main(String[] args) {
        showInt(new Integer(10));
        showInt(new Integer(20));
    }
    public static void showInt(int i) {
        System.out.println("value of int = " + i);
    }
}