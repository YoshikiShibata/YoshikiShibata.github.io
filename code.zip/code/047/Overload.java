class Overload {

    static void foo(int x, int y) {
        System.out.println("foo(int,int) is invoked");
    }

    static void foo(Integer x, Integer y) {
        System.out.println("foo(Integer,Integer) is invoked");
    }

    public static void main(String[] args) {
        foo(1,1);
        foo(new Integer(1), new Integer(1));
    }
}