class ArrayOfArray {
    public static void main(String[] args) {
        int[][] intTable = new int [][] { 
                    {0},
                    {0, 1},
                    {0, 1, 2},
                    {0, 1, 2, 3}};  

        for (int[] ia : intTable) {
            for (int i : ia) {
                System.out.print(i + " ");
            }
            System.out.println();
        }
    }
}