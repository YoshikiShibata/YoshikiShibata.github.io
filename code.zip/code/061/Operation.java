public enum Operation {
    PLUS("+")       { double eval(double x, double y) { return x + y; }}, 
    MINUS("-")      { double eval(double x, double y) { return x - y; }},
    TIMES("*")      { double eval(double x, double y) { return x * y; }},
    DIVIDED_BY("/") { double eval(double x, double y) { return x / y; }};

    private final String name;

    Operation(String name)   { this.name = name; }

    public String toString() { return this.name; }

    // �萔�ŕ\���ꂽ�Z�p������s��
    abstract double eval(double x, double y);
}