public enum Operation implements Operative {
    PLUS("+")      { public double eval(double x, double y){ return x + y; }}, 
    MINUS("-")     { public double eval(double x, double y){ return x - y; }},
    TIMES("*")     { public double eval(double x, double y){ return x * y; }},
    DIVIDED_BY("/"){ public double eval(double x, double y){ return x / y; }};

    private final String name;

    Operation(String name)   { this.name = name; }

    public String toString() { return this.name; }

    public abstract double eval(double x, double y);
}