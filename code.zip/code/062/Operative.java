public interface Operative {
    double eval(double x, double y);
}