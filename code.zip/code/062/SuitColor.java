public class SuitColor {
    public enum Suit { CLUBS, DIAMONDS, HEARTS, SPADES }

    public static String suitColor(Suit suit) {
        switch (suit) {
            case CLUBS:
            case SPADES:
                return "black";
            case DIAMONDS:
            case HEARTS:
                return "red";
            default:
                throw new AssertionError("Unknown " + suit);
        }
    }

    public static void main(String[] args) {
        for (Suit s: Suit.values()) 
            System.out.println(s + " is " + suitColor(s));
    }
}