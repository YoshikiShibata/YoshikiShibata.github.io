public class SuitColor {
    public enum Suit { CLUBS, DIAMONDS, HEARTS, SPADES }

    public static String suitColor(Suit suit) {
        if (suit == Suit.CLUBS || suit == Suit.SPADES)
            return "black";
        else if (suit == Suit.DIAMONDS || suit == Suit.HEARTS)
            return "red";
        else 
            throw new AssertionError("Unknown " + suit);
        }
    }

    public static void main(String[] args) {
        for (Suit s: Suit.values()) 
            System.out.println(s + " is " + suitColor(s));
    }
}