import java.util.EnumMap;

class EnumMapSample {
    enum Suit {CLUBS, DIAMONDS, HEARTS, SPADES}

    public static void main(String[] args) {
        EnumMap<Suit,String> map = new EnumMap<Suit, String>(Suit.class);

        map.put(Suit.CLUBS, "black");
        map.put(Suit.DIAMONDS, "red");
        map.put(Suit.HEARTS, "red");
        map.put(Suit.SPADES, "black");
    }
}