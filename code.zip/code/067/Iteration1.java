public class Iteration1 {
    public enum Suit { CLUBS, DIAMONDS, HEARTS, SPADES }
    
    public static void main(String[] args) {
        for (Suit s: Suit.values()) 
            System.out.println(s);
    }
}