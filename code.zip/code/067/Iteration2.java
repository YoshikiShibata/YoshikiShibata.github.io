import java.util.EnumSet;

public class Iteration2 {
    public enum Day { 
             SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY }
             
    public static void main(String[] args) {
        System.out.print("Weedays:");
        for (Day d: EnumSet.range(Day.MONDAY, Day.FRIDAY)) 
            System.out.print(" " + d);
        System.out.println();
    }
}