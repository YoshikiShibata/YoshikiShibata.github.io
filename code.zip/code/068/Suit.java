public enum Suit {
    CLUBS("clubs")       { String color() { return "black"; }}, 
    DIAMONDS("diamonds") { String color() { return "red"; }}, 
    HEARTS("hearts")     { String color() { return "red"; }}, 
    SPADES("spades")     { String color() { return "black"; }};

    private final String name;
    Suit(String name) { this.name = name; }
    public String toString()  { return name; }
    abstract String color();
}