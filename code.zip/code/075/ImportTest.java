import static java.lang.Math.exp;

class ImportTest {

    private void exp() { /* ... */ }

    public double tanh(double x) {
        return (exp(x) - exp(-x)) / (exp(x) + exp(-x)); // NG! �R���p�C���G���[
    }
}