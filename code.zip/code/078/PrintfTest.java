class PrintfTest {
    public static void main(String[] args) {
        int x = 10;
        int y = 20;
        int sum = x + y;
        System.out.printf("%d + %d = %d%n", x, y, sum);
    }
}