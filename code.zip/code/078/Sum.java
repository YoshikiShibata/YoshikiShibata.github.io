class Sum {
    static int sum(int ... numbers) {
        int total = 0;
        for (int i: numbers)
            total += i;
        return total;
    }

    public static void main(String[] args) {
        System.out.printf("%d%n", sum(1, 2, 3, 4, 5));
    }
}