class AClass {
    public void aMethod(String strArg, int intArg) {
        System.out.printf("strArg = %s, intArg = %d%n", strArg, intArg);
    }
}