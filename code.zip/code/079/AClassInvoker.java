import java.lang.reflect.*;

class AClassInvoker {
    public static void main(String[] args) throws Exception {
        Class c = Class.forName("AClass");
        Method m = c.getMethod("aMethod", String.class, int.class);
        m.invoke(c.newInstance(), "Hello", 10);
    }
}