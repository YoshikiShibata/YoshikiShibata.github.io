class ArrayPassingTest {
    public static void main(String[] args) {
        Object[] msg = new String[] {"How", "are", "you?"};
        System.out.printf("%s %s %s%n", msg);
    }
}