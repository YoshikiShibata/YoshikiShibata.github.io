class B extends A {
    void f(Object[]  o) { }
    void g(Object... o) { }
}