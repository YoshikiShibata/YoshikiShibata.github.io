import java.util.Arrays;
import java.util.Collection;
import static java.util.Collections.*;
import java.util.Set;

import com.sun.mirror.apt.AnnotationProcessor;
import com.sun.mirror.apt.AnnotationProcessorEnvironment;
import com.sun.mirror.apt.AnnotationProcessorFactory;
import com.sun.mirror.declaration.AnnotationTypeDeclaration;
import com.sun.mirror.declaration.TypeDeclaration;

public class AptFactory implements AnnotationProcessorFactory {
    private static final Collection<String> supportedAnnotations
        = unmodifiableCollection(Arrays.asList("*"));
    private static final Set<String> supportedOptions 
        = emptySet();
    
    public Collection<String> supportedAnnotationTypes() {
        return supportedAnnotations;
    }

    public Collection<String> supportedOptions() {
        return supportedOptions;
    }
    
    public AnnotationProcessor getProcessorFor(
            Set<AnnotationTypeDeclaration> atds, 
            AnnotationProcessorEnvironment env) {

        for (AnnotationTypeDeclaration atd: atds)
            System.out.println("Annotation Type = " + atd.getQualifiedName());
 
        for (TypeDeclaration typeDecl : env.getSpecifiedTypeDeclarations())
            System.out.println("Specified Type = " + typeDecl);

        return null;
    }
}