public @interface Authors {
    String[] value();
}