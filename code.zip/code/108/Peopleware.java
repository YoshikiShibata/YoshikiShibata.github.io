@Authors({"Tom DeMarco", "Timothy Lister"})
public class Peopleware {
    public void read() { }
}