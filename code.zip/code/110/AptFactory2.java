import static java.util.Collections.*;
import java.util.*;

import com.sun.mirror.apt.*;
import com.sun.mirror.declaration.*;
import com.sun.mirror.type.*;
import com.sun.mirror.util.*;

public class AptFactory2 implements AnnotationProcessorFactory {
    private static final Collection<String> supportedAnnotations
        = unmodifiableCollection(Arrays.asList("*"));
    private static final Set<String> supportedOptions = emptySet(); 
           
    public Collection<String> supportedAnnotationTypes() {
        return supportedAnnotations;
    }

    public Collection<String> supportedOptions() {
        return supportedOptions;
    }
    
    public AnnotationProcessor getProcessorFor(
            Set<AnnotationTypeDeclaration> atds, 
            AnnotationProcessorEnvironment env) {
        return new AptProcessor(env);
    }
    
    // A Simple Annotation Processor
    private static class AptProcessor implements AnnotationProcessor {
        private final AnnotationProcessorEnvironment env;
    
        public AptProcessor(AnnotationProcessorEnvironment env) {
            this.env = env;
        }
    
        public void process() {
            for (TypeDeclaration td: env.getSpecifiedTypeDeclarations()) {
                System.out.printf("Processing %s.java ...%n", td);
                
                printTypeDeclarationAnnotation(td);

                for (FieldDeclaration fd: td.getFields())
                    printFieldAnnotation(fd);

                for (MethodDeclaration md: td.getMethods())
                    printMethodAnnotation(md);
            }
        }

        private void printTypeDeclarationAnnotation(TypeDeclaration td) {
            System.out.println("class or interface : " + td);
            for (AnnotationMirror am: td.getAnnotationMirrors())
                    printAnnotationMirror(am);
        }

        private void printFieldAnnotation(FieldDeclaration fd) {
            System.out.println("field: " + fd);
            for (AnnotationMirror am: fd.getAnnotationMirrors())
                    printAnnotationMirror(am);
        }

        private void printMethodAnnotation(MethodDeclaration md) {
            System.out.println("method: " + md);
            for (AnnotationMirror am: md.getAnnotationMirrors())
                    printAnnotationMirror(am);
        }

        private void printAnnotationMirror(AnnotationMirror am) {
            System.out.println(" type : " + am.getAnnotationType());
            for (Map.Entry<AnnotationTypeElementDeclaration,AnnotationValue> 
                        e: am.getElementValues().entrySet()) {
                AnnotationTypeElementDeclaration name = e.getKey();
                AnnotationValue value = e.getValue();
                System.out.println(" "+ name.getSimpleName() +" : " +value);
            }    
        }
    }
}