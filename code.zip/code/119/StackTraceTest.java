class StackTraceTest {
    public static void main(String[] args) {

        StackTraceElement[] ste = createThrowable().getStackTrace();

        for (StackTraceElement e: ste) {
            System.out.printf("%s: line %2d: %s#%s%n", 
                e.getFileName(), e.getLineNumber(),
                e.getClassName(), e.getMethodName());
        }
    }
    
    private static Throwable createThrowable() {
        return new Throwable();
    }
}