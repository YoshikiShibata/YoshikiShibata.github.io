class ThreadSynchronization extends Thread {
    private int x;
    
    public ThreadSynchronization(int x) { this.x = x; }
	
    public void run() {
        System.out.println("run: x = " + x);
        x = 2;
    }
	
    public int getX() { return x; }
	
	public static void main(String[] args) throws InterruptedException  {
        ThreadSynchronization ts = new ThreadSynchronization(1);
        ts.start();
        ts.join();
        System.out.println("main: x = " + ts.getX());
    }
}