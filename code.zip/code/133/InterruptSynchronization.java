class InterruptSynchronization extends Thread {
    private int x;

    public void run() {
        while (true) {
            try {
                Thread.sleep(3600*1000);
            } catch (InterruptedException e) {
                System.out.println("run: x = " + x);
            }
        }
    }

    public void setX(int x) {
        this.x = x;
        interrupt();
    }

    public static void main(String[] args) throws Exception {
        InterruptSynchronization is = new InterruptSynchronization();
        is.start();
        for (int i = 0; i < 10; i++) {
            is.setX(i);
            Thread.sleep(1000);
        }
    }
}