import java.util.*;

class MapDemo {
    public static void main(String[] args) {
        Map<Integer, Integer> map = new HashMap<Integer,Integer>();

        for (int i = 0; i < 10; i++ ) 
            map.put(i, i*i);

        for (Map.Entry<Integer, Integer> entry: map.entrySet()) {
            System.out.printf("%d ", entry.getKey());
        }
        System.out.println();
    }
}