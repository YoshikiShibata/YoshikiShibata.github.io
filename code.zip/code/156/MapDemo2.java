import java.util.*;

class MapDemo2 {
    public static void main(String[] args) {
        Map<Integer, Integer> map = new LinkedHashMap<Integer,Integer>(
                                                       16, 0.75f, true);

        for (int i = 0; i < 10; i++ ) 
            map.put(i, i*i);
        showMap(map);

        map.get(7);
        map.get(5);
        map.get(3);

        showMap(map);
    }

    private static void showMap(Map<Integer, Integer> map) {
        for (Map.Entry<Integer, Integer> entry: map.entrySet()) {
            System.out.printf("%d ", entry.getKey());
        }
        System.out.println();
    }
}