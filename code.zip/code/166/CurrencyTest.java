import java.util.Currency;
import java.util.Locale;

public class CurrencyTest {
    public static void main(String[] args) {
        Currency cr = Currency.getInstance(Locale.getDefault());
        System.out.printf("Currency Code = %s, Symbol = %s, "
                            + "DefaultFractionDigits = %d%n",
            cr.getCurrencyCode(), 
            cr.getSymbol(), 
            cr.getDefaultFractionDigits());
    }
}