class XlintTest {

    void foo() {
        try {
        } finally {
            throw new AssertionError();
        }
    }

    void bar(int x) {
        switch (x) {
            case 0: System.out.println("0");
            case 1: System.out.println("1");
                    break;
            case 2:
            case 3:
                    System.out.println("2 or 3");
                    break;
        }
    }
}