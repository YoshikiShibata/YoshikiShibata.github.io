/*
 * Copyright (C) 2008 - 2011 Yoshiki Shibata. All rights reserved.
 */
package jp.ne.sonet.ca2.yshibata.client.digitalclock;

import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.i18n.client.DateTimeFormat.PredefinedFormat;

/**
 * Enum for Data and Time formats.
 */
public enum DateTimeFormatPattern {
  FULL_DATE("Full Date",               PredefinedFormat.DATE_FULL),
  FULL_DATE_TIME("Full Date/Time",     PredefinedFormat.DATE_TIME_FULL),
  FULL_TIME("Full Time",               PredefinedFormat.TIME_FULL),
  LONG_DATE("Long Date",               PredefinedFormat.DATE_LONG),
  LONG_DATE_TIME("Long Date/Time",     PredefinedFormat.DATE_TIME_LONG),
  LONG_TIME("Long Time",               PredefinedFormat.TIME_LONG),
  MEDIUM_DATE("Medium Date",           PredefinedFormat.DATE_MEDIUM),
  MEDIUM_DATE_TIME("Medium Date/Time", PredefinedFormat.DATE_TIME_MEDIUM),
  MEDIUM_TIME("Medium Time",           PredefinedFormat.TIME_MEDIUM);
  
  DateTimeFormatPattern(String displayName, DateTimeFormat.PredefinedFormat format) {
    this.format = DateTimeFormat.getFormat(format);
    this.displayName = displayName;
  }
  private final DateTimeFormat format;
  private final String displayName;
  
  public DateTimeFormat getFormat() {
    return format;
  }
  
  public String getDisplayName() {
    return displayName;
  }
  
  public static DateTimeFormat getFormat(String displayName) {
    for (DateTimeFormatPattern pattern: DateTimeFormatPattern.values()) {
      if (displayName.equals(pattern.getDisplayName()))
        return pattern.getFormat();
    }
    throw new AssertionError("undefined display name");
  }
}
