/*
 * Copyright (C) 2008 - 2011 Yoshiki Shibata. All rights reserved.
 */
package jp.ne.sonet.ca2.yshibata.client.digitalclock;

import java.util.Date;

import jp.ne.sonet.ca2.yshibata.client.util.Color;
import jp.ne.sonet.ca2.yshibata.client.util.StyledLabel;

import com.google.gwt.dom.client.Style;
import com.google.gwt.event.dom.client.BlurEvent;
import com.google.gwt.event.dom.client.BlurHandler;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.DoubleClickEvent;
import com.google.gwt.event.dom.client.DoubleClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyPressEvent;
import com.google.gwt.event.dom.client.KeyPressHandler;
import com.google.gwt.event.dom.client.MouseDownEvent;
import com.google.gwt.event.dom.client.MouseDownHandler;
import com.google.gwt.event.dom.client.MouseOutEvent;
import com.google.gwt.event.dom.client.MouseOutHandler;
import com.google.gwt.event.dom.client.MouseOverEvent;
import com.google.gwt.event.dom.client.MouseOverHandler;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.i18n.client.LocaleInfo;
import com.google.gwt.i18n.client.DateTimeFormat.PredefinedFormat;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.CheckBox;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.DisclosurePanel;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.FlexTable.FlexCellFormatter;

/**
 * Digital Clock widget.
 */
public class DigitalClock extends Composite {
  private static final String DIGITAL_CLOCK_PROPERTIES_TITLE_AND_VERSION = 
                                    "Digital Clock Properties (V1.14)";
  
  VerticalPanel clockPanel = new VerticalPanel();
  private StyledLabel     currentTime = new StyledLabel();
  private StyledLabel     currentTime2 = new StyledLabel();
  private Date            currentDate = new Date();
  private final Color     defaultColor = Color.BLACK;
  private final Color     defaultBackgroundColor = Color.WHITE;
  private DateTimeFormat  defaultFormat = 
                      DateTimeFormatPattern.MEDIUM_DATE_TIME.getFormat();
  private DialogBox       dialog = createDialog();
  
  private DraggablePopup draggableClock = new DraggablePopup(false, false);

  /**
   * Constructs an instance of this Widget.
   */
  public DigitalClock() {
    currentDate.setTime(System.currentTimeMillis());
    currentTime.setText(
        DateTimeFormat.getFormat(PredefinedFormat.DATE_TIME_MEDIUM).format(currentDate));
    
    clockPanel.setWidth("100%");
    clockPanel.setHorizontalAlignment(VerticalPanel.ALIGN_RIGHT);
    clockPanel.add(currentTime);
    dialog.setAnimationEnabled(true);
    
    draggableClock.addLabel(currentTime2);
    draggableClock.addDoubleClickHandler(new DoubleClickHandler() {
      public void onDoubleClick(DoubleClickEvent event) {
        dialog.show();
      }
    });
    
    currentTime.addMouseDownHandler(new MouseDownHandler() {
      public void onMouseDown(MouseDownEvent event) {
        dialog.setPopupPosition(event.getClientX()-currentTime.getOffsetWidth(), 
                                event.getClientY()+20);
        dialog.show();
      }
    });
    
    initWidget(clockPanel);
    
    Timer timer = new Timer() {
      @Override
      public void run() {
        currentDate.setTime(System.currentTimeMillis());
        currentTime.setText(defaultFormat.format(currentDate));
        currentTime2.setText(defaultFormat.format(currentDate));
      }
    };
    timer.scheduleRepeating(1000);
    
    currentTime.addMouseOverHandler(new MouseOverHandler() {
      public void onMouseOver(MouseOverEvent event) {
        DOM.setStyleAttribute(currentTime.getElement(), "cursor", "pointer");
      }
    });
    
    currentTime.addMouseOutHandler(new MouseOutHandler() {
      public void onMouseOut(MouseOutEvent event) {
        DOM.setStyleAttribute(currentTime.getElement(), "cursor", "default");
      }
    });
    
    currentTime.setTitle("クリックするとプロパティが開きます");
    currentTime2.setTitle("Double Click to show the Properties");
  }
  
  private DialogBox createDialog() {
    final DialogBox dialog = new DialogBox(false, false);
    
    dialog.setText(DIGITAL_CLOCK_PROPERTIES_TITLE_AND_VERSION);
    VerticalPanel dialogContents = new VerticalPanel();
    dialogContents.setSpacing(4);
    dialog.setWidget(dialogContents);
    
    FlexTable layout = new FlexTable();
    
    int row = 0;
    createStyleCheckBoxes(layout, row++);
    createFontSizeList(layout, row++);
    createFontFamilyList(layout, row++);
    createColorList(layout, row++);
    createBackgroundColorList(layout, row++);
    
    DisclosurePanel advancedSettings = new DisclosurePanel("Advanced Settings");
    advancedSettings.setAnimationEnabled(true);
    FlexTable advancedLayout = new FlexTable();
    
    createDecorationCheckBox(advancedLayout, 0);
    createDateTimeFormatList(advancedLayout, 1);
    createDetachClockCheckBox(advancedLayout, 2);
    advancedSettings.add(advancedLayout);
    
    layout.setWidget(row, 0, advancedSettings);
    FlexCellFormatter cellFormatter = layout.getFlexCellFormatter();
    cellFormatter.setColSpan(row, 0, 3);
    
    dialogContents.add(layout);
    
    createCloseButton(dialog, dialogContents);
    return dialog;
  }

  private void createStyleCheckBoxes(FlexTable layout, int row) {
    createPropertyLabel(layout, row, "Font Style:");
    
    final CheckBox bold = new CheckBox("bold");
    bold.getElement().getStyle().setFontWeight(Style.FontWeight.BOLD);
    
    bold.addClickHandler(new ClickHandler() {
      public void onClick(ClickEvent event) {
        currentTime.setBold(bold.getValue());
        currentTime2.setBold(bold.getValue());
      }
    });
    
    layout.setWidget(row, 1, bold);
    
    final CheckBox italic = new CheckBox("italic");
    italic.getElement().getStyle().setFontStyle(Style.FontStyle.ITALIC);
    
    italic.addClickHandler(new ClickHandler() {
      public void onClick(ClickEvent event) {
        currentTime.setItalic(italic.getValue());
        currentTime2.setItalic(italic.getValue());
      }
    });
    
    layout.setWidget(row, 2, italic);
  }
  
  private void createPropertyLabel(FlexTable layout, int row, String label) {
    layout.setWidget(row, 0, new Label(label));
    FlexCellFormatter cellFormatter = layout.getFlexCellFormatter();
    cellFormatter.setHorizontalAlignment(row, 0, 
        HasHorizontalAlignment.ALIGN_RIGHT);
  }
  
  private void createDecorationCheckBox(FlexTable layout, int row) {
    createPropertyLabel(layout, row, "Font Decoration:");
    
    final CheckBox underline = new CheckBox("underline");
    underline.getElement().getStyle().setTextDecoration(
        Style.TextDecoration.UNDERLINE);
    
    underline.addClickHandler(new ClickHandler() {
      public void onClick(ClickEvent event) {
        currentTime.setUnderline(underline.getValue());
        currentTime2.setUnderline(underline.getValue()); 
      }
    });
    
    layout.setWidget(row, 1, underline);
  }
  
  private void createFontSizeList(FlexTable layout, int row) {
    final NumericBox fontSize = new NumericBox();
    fontSize.setIntValue(12);
    currentTime.setFontSize(12);
    currentTime2.setFontSize(12);
    fontSize.setWidth("40pt");
    
    fontSize.addKeyPressHandler(new KeyPressHandler() {
      public void onKeyPress(KeyPressEvent event) {
        int keyCode = event.getNativeEvent().getKeyCode();
        
        if (keyCode == KeyCodes.KEY_ENTER) {
          setFontSize(fontSize);
        }
      }
    });
    
    fontSize.addBlurHandler(new BlurHandler() {
      public void onBlur(BlurEvent event) {
        setFontSize(fontSize);
      }
    });
    
    createPropertyLabel(layout, row, "Font Size:");
    layout.setWidget(row, 1, fontSize);
  }
  
  private void setFontSize(final NumericBox fontSize) {
    try {
      int value = fontSize.getIntValue();
      
      if (value <= 0) {
        showInvalidValueAlert();
      } else {
        currentTime.setFontSize(value);
        currentTime2.setFontSize(value);
      }
    } catch (NumberFormatException e) {
      showInvalidValueAlert();
    }
  }

  private void showInvalidValueAlert() {
    Window.alert("Invalid Font Size: Must be a positive integer");
  }
  
  private void createColorList(FlexTable layout, int row) {
    final ListBox colorList = createColorList(defaultColor);

    colorList.addChangeHandler(new ChangeHandler() {
      public void onChange(ChangeEvent event) {
        Color selectedColor = getSelectedColor(colorList);
        currentTime.setColor(selectedColor);
        currentTime2.setColor(selectedColor);
      }
    });
    
    createPropertyLabel(layout, row, "Font Color:");
    layout.setWidget(row, 1, colorList);
  }
  
  private ListBox createColorList(Color initialColor) {
    ListBox colorList = new ListBox();
    
    colorList.setVisibleItemCount(1);
    int selectedIndex = 0;
    for (Color color: Color.values()) {
      colorList.addItem(color.colorName());
      if (color == initialColor)
        colorList.setSelectedIndex(selectedIndex);
      selectedIndex++;
    }
    
    return colorList;
  }
  
  private Color getSelectedColor(ListBox colorList) {
    String colorName = colorList.getValue(colorList.getSelectedIndex());
    return Color.fromColorName(colorName);
  }
  
  private void createBackgroundColorList(FlexTable layout, int row) {
    final ListBox colorList = createColorList(defaultBackgroundColor);
    
    colorList.addChangeHandler(new ChangeHandler() {
      public void onChange(ChangeEvent event) {
        Color selectedColor = getSelectedColor(colorList);
        currentTime.setBackgroundColor(selectedColor);
        currentTime2.setBackgroundColor(selectedColor);
      }
    });
    
    createPropertyLabel(layout, row, "Background Color:");
    layout.setWidget(row, 1, colorList);
  }
  
  private void createFontFamilyList(FlexTable layout, int row) {
    final ListBox fontFamilyList = new ListBox();
    final StyledLabel.FontFamily[] families = StyledLabel.FontFamily.values();
    for (StyledLabel.FontFamily family: families)
    	fontFamilyList.addItem(family.familyName());
    
    fontFamilyList.addChangeHandler(new ChangeHandler() {
      public void onChange(ChangeEvent event) {
        currentTime.setFontFamily(families[fontFamilyList.getSelectedIndex()]);
        currentTime2.setFontFamily(families[fontFamilyList.getSelectedIndex()]);
      }
    });
    
    createPropertyLabel(layout, row, "Font Family:");
    layout.setWidget(row, 1, fontFamilyList);
  }
  
  private void createDateTimeFormatList(FlexTable layout, int row) {
    layout.setWidget(row, 0, new Label("Date Time Format:"));
    final ListBox formatList = new ListBox();
    int selectedIndex = 0;
    for (DateTimeFormatPattern pattern: DateTimeFormatPattern.values()) {
      formatList.addItem(pattern.getDisplayName());
      if (pattern.getFormat() == defaultFormat)
        formatList.setSelectedIndex(selectedIndex);
      selectedIndex++;
    }
   
    formatList.addChangeHandler(new ChangeHandler() {
      public void onChange(ChangeEvent event) {
        String value = formatList.getValue(formatList.getSelectedIndex());
        defaultFormat = DateTimeFormatPattern.getFormat(value);
      }   
    });
    
    layout.setWidget(row, 1, formatList);
  }
  
  private void createDetachClockCheckBox(FlexTable layout, int row) {
    final CheckBox detached = new CheckBox("detached");
    
    createPropertyLabel(layout, row, "Clock Mode:");
    
    detached.addClickHandler(new ClickHandler() {
      private boolean showFirstTime = true;
      
      public void onClick(ClickEvent event) {
        if (detached.getValue()){ 
          if (showFirstTime) {
            draggableClock.setPopupPosition(
                currentTime.getOffsetWidth() / 2,  
                currentTime.getAbsoluteTop());
            showFirstTime = false;
          }
          clockPanel.clear();
          draggableClock.show();
        } else {
          draggableClock.hide();
          clockPanel.add(currentTime);
        }
      }
    });
    layout.setWidget(row, 1, detached);
  }
  
  private void createCloseButton(final DialogBox dialog,
    VerticalPanel dialogContents) {
    Button closeButton = new Button("Close", new ClickHandler() {
      public void onClick(ClickEvent event) {
        dialog.hide();
      }
    });
    
    dialogContents.add(closeButton);
    dialogContents.setCellHorizontalAlignment(closeButton,
    		  LocaleInfo.getCurrentLocale().isRTL() ? 
                HasHorizontalAlignment.ALIGN_LEFT :
        	    HasHorizontalAlignment.ALIGN_RIGHT);
  }
}
