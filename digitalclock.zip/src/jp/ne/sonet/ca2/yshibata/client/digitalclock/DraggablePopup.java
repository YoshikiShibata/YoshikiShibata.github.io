/*
 * Copyright (C) 2008 - 2011 by Yoshiki Shibata. All rights reserved.
 */
package jp.ne.sonet.ca2.yshibata.client.digitalclock;

import com.google.gwt.event.dom.client.DoubleClickEvent;
import com.google.gwt.event.dom.client.DoubleClickHandler;
import com.google.gwt.event.dom.client.HasDoubleClickHandlers;
import com.google.gwt.event.dom.client.MouseDownEvent;
import com.google.gwt.event.dom.client.MouseDownHandler;
import com.google.gwt.event.dom.client.MouseMoveEvent;
import com.google.gwt.event.dom.client.MouseMoveHandler;
import com.google.gwt.event.dom.client.MouseUpEvent;
import com.google.gwt.event.dom.client.MouseUpHandler;
import com.google.gwt.event.shared.HandlerRegistration;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.PopupPanel;

public class DraggablePopup extends PopupPanel 
            implements HasDoubleClickHandlers {
  private Dragger dragger = new Dragger();
  private boolean dragging = false;
  private PreventDefaultDuringDragging preventDefaultDuringDragging =
                          new PreventDefaultDuringDragging();
  private Label label = null;
  
  public DraggablePopup() {
    this(false, true);
  }
  
  public DraggablePopup(boolean autoHide) {
    this(autoHide, true);
  }
  
  public DraggablePopup(boolean autoHide, boolean modal) {
    super(autoHide, modal);
  }
  
  public HandlerRegistration addDoubleClickHandler(DoubleClickHandler handler) {
    return addDomHandler(handler, DoubleClickEvent.getType());
  }
  
  private class Dragger 
    implements MouseDownHandler, MouseMoveHandler, MouseUpHandler {
    private int dragStartX;
    private int dragStartY;
    
    public void onMouseDown(MouseDownEvent event) {
      DOM.setCapture(label.getElement());
      dragging = true;
      dragStartX = event.getClientX();
      dragStartY = event.getClientY();
    }
    
    public void onMouseMove(MouseMoveEvent event) {
      if (dragging) {
        int absX = event.getClientX() + DraggablePopup.this.getAbsoluteLeft();
        int absY = event.getClientY() + DraggablePopup.this.getAbsoluteTop();

        DraggablePopup.this.setPopupPosition(
            absX - dragStartX, absY - dragStartY);
        dragStartX = event.getClientX();
        dragStartY = event.getClientY();
      }
    }

    public void onMouseUp(MouseUpEvent event) {
      dragging = false;
      DOM.releaseCapture(label.getElement()); 
    }
  }
  
  public void addLabel(Label label) {
    super.add(label);
    this.label = label;
    
    label.addMouseDownHandler(dragger);
    label.addMouseMoveHandler(dragger);
    label.addMouseUpHandler(dragger);
    
    label.addMouseOverHandler(preventDefaultDuringDragging);
    label.addMouseOutHandler(preventDefaultDuringDragging);
  }
}
