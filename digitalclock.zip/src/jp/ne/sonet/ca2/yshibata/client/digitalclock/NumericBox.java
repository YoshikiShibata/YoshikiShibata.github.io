/*
 * Copyright (C) 2008 - 2011 Yoshiki Shibata. All rights reserved.
 */
package jp.ne.sonet.ca2.yshibata.client.digitalclock;

import com.google.gwt.event.dom.client.BlurHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyPressEvent;
import com.google.gwt.event.dom.client.KeyPressHandler;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.TextBox;

/**
 * NumericBox accepts only sign symbols, digits, and decimal point.
 */
public class NumericBox extends Composite {
  private TextBox inputBox = new TextBox();
  
  public NumericBox() {
    initWidget(inputBox);
    inputBox.addKeyPressHandler(new KeyFilter());
  }
  
  public int getIntValue() {
    String inputText = inputBox.getText();
    if (inputText.length() == 0)
      return 0;
    
    return Integer.valueOf(inputText);
  }
  
  public void setIntValue(int value) {
    inputBox.setText(String.valueOf(value));
  }
  
  public void addKeyPressHandler(KeyPressHandler handler) {
    inputBox.addKeyPressHandler(handler);
  }
  
  public void addBlurHandler(BlurHandler handler) {
    inputBox.addBlurHandler(handler);
  }
  
  private class KeyFilter implements KeyPressHandler {

    public void onKeyPress(KeyPressEvent event) {
      char charCode = event.getCharCode();
      
      if ((charCode == '+' || charCode == '-') &&
          inputBox.getText().length() == 0)
        return;
      
      if ('0' <= charCode && charCode <='9') 
        return;
      
      if (charCode == '.' && !inputBox.getText().contains(".")) 
        return;
      
      int keyCode = event.getNativeEvent().getKeyCode();
      
      if (keyCode == KeyCodes.KEY_DELETE ||
          keyCode == KeyCodes.KEY_BACKSPACE ||
          keyCode == KeyCodes.KEY_ENTER)
        return;
      
      inputBox.cancelKey();
    } 
  }
}
