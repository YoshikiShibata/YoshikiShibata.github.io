/*
 * Copyright (C) 2008 - 2011 Yoshiki Shibata. All rights reserved.
 */
package jp.ne.sonet.ca2.yshibata.client.digitalclock;

import com.google.gwt.event.dom.client.MouseOutEvent;
import com.google.gwt.event.dom.client.MouseOutHandler;
import com.google.gwt.event.dom.client.MouseOverEvent;
import com.google.gwt.event.dom.client.MouseOverHandler;
import com.google.gwt.event.shared.HandlerRegistration;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Event;
import com.google.gwt.user.client.Event.NativePreviewEvent;
import com.google.gwt.user.client.Event.NativePreviewHandler;

public class PreventDefaultDuringDragging implements MouseOverHandler, MouseOutHandler {
  private final PreventEventPreview preview = new PreventEventPreview();
  HandlerRegistration handlerRegistration = null;
    
  private class PreventEventPreview implements NativePreviewHandler {
    public void onPreviewNativeEvent(NativePreviewEvent event) {
      Event nativeEvent = Event.as(event.getNativeEvent());
      switch (nativeEvent.getTypeInt()) {
        case Event.ONMOUSEDOWN:
        case Event.ONMOUSEMOVE:
          DOM.eventPreventDefault(nativeEvent);
      }
    }
  }

  public void onMouseOver(MouseOverEvent event) {
    if (handlerRegistration == null)
      handlerRegistration = Event.addNativePreviewHandler(preview);
  }

  public void onMouseOut(MouseOutEvent event) {
    if (handlerRegistration != null) {
      handlerRegistration.removeHandler();
      handlerRegistration = null;
    }
  }
}
