/*
 * Copyright (C) 2008 - 2011 Yoshiki Shibata. All rights reserved.
 */
package jp.ne.sonet.ca2.yshibata.client.util;

/**
 * Enum for predefined Colors
 */
public enum Color {
  WHITE("#FFFFFF"),
  LIGHT_GRAY("#C0C0C0"),
  GRAY("#808080"),
  DARK_GRAY("#404040"),
  BLACK("#000000"),
  RED("#FF0000"),
  PINK("#FFAFAF"),
  ORANGE("#FFC800"),
  YELLOW("FFFF00"),
  GREEN("#00FF00"), 
  MAGENTA("#FF00FF"),
  CYAN("#00FFFF"),
  BLUE("#0000FF");
  
  Color(String hexValue) {
    this.hexValue = hexValue;
  }

  private String hexValue;
  
  /**
   * Obtains the hex value of this color.
   * 
   * @return the hex value of this color.
   */
  public String getHexValue() {
    return hexValue;
  }
  
  /**
   * Obtains name of this color for displaying to users
   * 
   * @return name of this color.
   */
  public String colorName() {
    return name().toLowerCase().replace('_', ' ');
  }
  
  /**
   * Obtains an instance of Color by its name.
   * 
   * @param colorName the name of color
   * @return instance corresponding to the name.
   * @throws NullPointerException if <code>colorName</code> is null
   */
  public static Color fromColorName(String colorName) {
	if (colorName == null)
      throw new NullPointerException("colorName is null");
	
    return valueOf(colorName.toUpperCase().replace(' ', '_'));
  }
}
