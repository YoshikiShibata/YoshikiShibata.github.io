/*
 * Copyright (C) 2008 - 2011 Yoshiki Shibata. All rights reserved.
 */
package jp.ne.sonet.ca2.yshibata.client.util;


import com.google.gwt.dom.client.Style;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.ui.Label;

/**
 * Styled label is a label to which style attributes can be set.
 */
public class StyledLabel extends Label {
  
  /**
   * enum for standard font families for Web browser.
   */
  public enum FontFamily {
	DEFAULT("default"),
    SERIF("serif"),
    SANS_SERIF("sans-serif"),
    CURSIVE("cursive"),
    FANTASY("fantasy"),
    MONOSPACE("monospace");
    
    FontFamily(String familyName) {
      this.familyName = familyName;
    }
    
    /**
     * Obtains the name of font family.
     * 
     * @return then name of font family.
     */
    public String familyName() {
      return familyName;
    }
    
    private final String familyName;
  }
  
  /**
   * Constructs an instance without any label text.
   */
  public StyledLabel() {
  }
  
  /**
   * Constructs an instance with the specified label text
   * @param text label text
   */
  public StyledLabel(String text) {
    super(text);
  }
  
  private Style style() {
    return getElement().getStyle();
  }
  
  /**
   * sets bold attribute to this label.
   * 
   * @param bold true if bold attribute is to be set.
   * @return this label.
   */
  public StyledLabel setBold(boolean bold) {
    style().setFontWeight(bold ? Style.FontWeight.BOLD : Style.FontWeight.NORMAL);
    return this;
  }
  
  /**
   * Sets italic attribute to this label.
   * 
   * @param italic true if italic attribute is to be set.
   * @return this label
   */
  public StyledLabel setItalic(boolean italic) {
    style().setFontStyle(italic ? Style.FontStyle.ITALIC : Style.FontStyle.NORMAL);
    return this;
  }
  
  /**
   * Sets font size to this label.
   * 
   * @param fontSize font size
   * @return this
   * @throws IllegalArgumentException if <code>fontSize</code> is less than or equal to zero.
   */
  public StyledLabel setFontSize(int fontSize) {
	if (fontSize <= 0)
	  throw new IllegalArgumentException("fontSize is less than or equal to zero");
	
	style().setFontSize(fontSize, Unit.PT);
    return this;
  }
  
  /**
   * Sets text color to this label.
   * 
   * @param color a text color
   * @return this
   * @throws NullPointerException if <code>color</code> is null.
   */
  public StyledLabel setColor(Color color) {
	if (color == null) 
      throw new NullPointerException("color is null");
	
	style().setColor(color.getHexValue());
    return this;
  }
  
  /**
   * Sets background color to this label.
   * 
   * @param color background color
   * @return this
   * @throws NullPointerException if <code>color</color> is null.
   */
  public StyledLabel setBackgroundColor(Color color) {
	if (color == null)
	  throw new NullPointerException("color is null");
	
	style().setBackgroundColor(color.getHexValue());
	return this;
  }
  
  /**
   * Sets underline to this label.
   * 
   * @param underline true if underline is to be set.
   * @return this
   */
  public StyledLabel setUnderline(boolean underline) {
    style().setTextDecoration(underline ? Style.TextDecoration.UNDERLINE :
                                          Style.TextDecoration.NONE);
    return this;
  }
  
  /**
   * Sets font family to this label.
   * 
   * @param family a FontFamily
   * @return this
   * @throws NullPointerException if <code>family</code> is null
   */
  public StyledLabel setFontFamily(FontFamily family) {
	if (family == null)
	  throw new NullPointerException("family is null");
	
    DOM.setStyleAttribute(getElement(), "fontFamily", family.familyName());
    return this;
  }
}
