package jp.ne.so_net.ca2.yshibata;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestArrayUtil {

	@Test(expected=NullPointerException.class)
	public void testNullArgument() {
		ArrayUtil.rearrangeByFirstElement(null);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testEmptyArgument() {
		ArrayUtil.rearrangeByFirstElement(new int[0]);
	}
	
	@Test
	public void testOneElement() {
		int result = ArrayUtil.rearrangeByFirstElement(
						new int[] {1});
		assertEquals(0, result);
	}
	
	@Test
	public void test3Elements() {
		int[] a = new int[] {2, 3, 1};
		int result = ArrayUtil.rearrangeByFirstElement(a);
		assertEquals(1, result);
		assertTrue(isCorrectlyArranged(a, 1, 2));
	}
	
	@Test
	public void testSameElements() {
		int[] a = new int[] {7, 7, 7, 7, 7};
		int result = ArrayUtil.rearrangeByFirstElement(a);
		assertEquals(0, result);
		assertTrue(isCorrectlyArranged(a, 0, 7));
	}
	@Test
	public void testSomeSameElements() {
		int[] a = new int[] {7, 1, 2, 7, 7};
		int result = ArrayUtil.rearrangeByFirstElement(a);
		assertEquals(2, result);
		assertTrue(isCorrectlyArranged(a, 2, 7));
	}
	
	@Test
	public void test7ElmentsInOrder() {
		int[] a = new int[] {0, 1, 2, 3, 4, 5, 6};
		int result = ArrayUtil.rearrangeByFirstElement(a);
		assertEquals(0, result);
		assertTrue(isCorrectlyArranged(a, 0, 0));
	}
	
	@Test
	public void test7ElmentsInReverse() {
		int[] a = new int[] {6, 5, 4, 3, 2, 1, 0};
		int result = ArrayUtil.rearrangeByFirstElement(a);
		assertEquals(6, result);
		assertTrue(isCorrectlyArranged(a, 6, 6));
	}
	@Test
	public void test7Elments() {
		int[] a = new int[] {3, 1, 2, 0, 4, 5, 6};
		int result = ArrayUtil.rearrangeByFirstElement(a);
		assertEquals(3, result);
		assertTrue(isCorrectlyArranged(a, 3, 3));
	}
	
	private boolean isCorrectlyArranged(
			int[] a, int index, int value) {
		for (int i = 0; i < a.length; i++) {
			if (i < index) {
				if (a[i] > a[index])
					return false;
			} else if (i == index) {
				if (a[i] != value)
					return false;
			} else {
				if (a[index] > a[i])
					return false;
			}
		}
		return true;
	}

}
