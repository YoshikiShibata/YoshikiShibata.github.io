package jp.ne.so_net.ca2.yshibata;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestStringUtil {

	@Test(expected=NullPointerException.class)
	public void testNullArgument() {
		StringUtil.insertCommas(null);
	}
	@Test(expected=IllegalArgumentException.class)
	public void testZeroLengthInput() {
		StringUtil.insertCommas("");
	}
	@Test(expected=IllegalArgumentException.class)
	public void testNonDigitString() {
		StringUtil.insertCommas("123abc");
	}
	@Test
	public void test1Digit() {
		String result = StringUtil.insertCommas("1");
		assertEquals("1", result);
	}
	@Test
	public void test3Digits() {
		String result = StringUtil.insertCommas("123");
		assertEquals("123", result);
	}
	@Test
	public void test4Digits() {
		String result = StringUtil.insertCommas("1234");
		assertEquals("1,234", result);
	}
	@Test
	public void test10Digits() {
		String result = StringUtil.insertCommas(
							"1234567890");
		assertEquals("1,234,567,890", result);
	}
	
	
	
}
